<?php foreach ($pasien as $row): ?>
<tr>
  <td><?= $row['id'] ?></td>
  <td><?= $row['nama'] ?></td>
  <td><?= $row['norm'] ?></td>
  <td><?= $row['nama_jenis_kelamin'] ?></td>
  <td><?= $row['nama_diagnosis'] ?? '-' ?></td>
  <td>
    <button class="btn btn-sm btn-warning btn-edit" data-id="<?= $row['id'] ?>">Edit</button>
    <button class="btn btn-sm btn-danger btn-delete" data-id="<?= $row['id'] ?>">Hapus</button>
  </td>
</tr>
<?php endforeach; ?>