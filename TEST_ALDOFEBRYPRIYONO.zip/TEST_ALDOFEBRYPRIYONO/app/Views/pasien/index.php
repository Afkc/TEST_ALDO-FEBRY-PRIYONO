<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>CRUD Pasien</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
</head>
<body>
  <div class="container mt-4">
    <h1>Data Pasien</h1>
    <button class="btn btn-primary mb-3" id="addPasien">Tambah Pasien</button>
    
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>ID</th>
          <th>Nama</th>
          <th>NORM</th>
          <th>Jenis Kelamin</th>
          <th>Diagnose</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody id="pasienList">
        <!-- AJAX loaded rows -->
      </tbody>
    </table>
  </div>

  <!-- Modal Form -->
  <div class="modal fade" id="pasienModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
      <form id="formPasien">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Form Pasien</h5>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
            <input type="hidden" id="pasien_id" name="id">
            <div class="form-group">
  <label>Jenis Kelamin</label>
  <select class="form-control" name="jenis_kelamin_id" required>
    <option value="">Pilih Jenis Kelamin</option>
    <option value="1">Laki-laki</option>
    <option value="2">Perempuan</option>
    <!-- Sesuaikan value dengan isi tabel jenis_kelamin -->
  </select>
</div>
            <div class="form-group">
              <label>Nama</label>
              <input type="text" class="form-control" name="nama" required>
            </div>
            <div class="form-group">
              <label>No RM</label>
              <input type="text" class="form-control" name="norm" required>
            </div>
            <div class="form-group">
              <label>Diagnosis</label>
              <input type="text" class="form-control" name="diagnosis" id="diagnosis" required>
            </div>
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-success">Simpan</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
          </div>
        </div>
      </form>
    </div>
  </div>

  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
  <script>
    $(document).ready(function() {
      loadPasien();

      function loadPasien() {
        $.get("<?= base_url('pasien/list') ?>", function(data) {
          $('#pasienList').html(data);
        });
      }

      $('#addPasien').click(function() {
        $('#formPasien')[0].reset();
        $('#pasien_id').val('');
        $('#pasienModal').modal('show');
      });

      $('#formPasien').submit(function(e) {
        e.preventDefault();
        const formData = $(this).serialize();
        const id = $('#pasien_id').val();
        const url = id ? `<?= base_url('pasien/update/') ?>${id}` : `<?= base_url('pasien/create') ?>`;

        $.post(url, formData, function(res) {
          if (res.status === 'success') {
            $('#pasienModal').modal('hide');
            loadPasien();
            // Tampilkan notifikasi sukses
            $('<div class="alert alert-success alert-dismissible fade show" role="alert">Data sudah disimpan.<button type="button" class="close" data-dismiss="alert">&times;</button></div>')
              .prependTo('.container')
              .delay(2000).fadeOut(500, function() { $(this).remove(); });
          } else {
            alert("Gagal menyimpan data.");
          }
        }, 'json');
      });

      $(document).on('click', '.btn-edit', function() {
        const id = $(this).data('id');
        $.get(`<?= base_url('pasien/get/') ?>${id}`, function(res) {
          $('[name="nama"]').val(res.nama);
          $('[name="norm"]').val(res.norm);
          $('[name="jenis_kelamin_id"]').val(res.jenis_kelamin_id);
          $('[name="diagnosis"]').val(res.diagnosis);
          $('#pasien_id').val(res.id);
          $('#pasienModal').modal('show');
        });
      });

      $(document).on('click', '.btn-delete', function() {
        const id = $(this).data('id');
        if (confirm('Yakin hapus data ini?')) {
          $.get(`<?= base_url('pasien/delete/') ?>${id}`, function(res) {
            console.log('Delete response:', res); // debug log
            if (res.status === 'deleted') {
              loadPasien();
              $('<div class="alert alert-success alert-dismissible fade show" role="alert">Data berhasil dihapus.<button type="button" class="close" data-dismiss="alert">&times;</button></div>')
                .prependTo('.container')
                .delay(2000).fadeOut(500, function() { $(this).remove(); });
            } else {
              alert(res.message || 'Gagal menghapus data.');
            }
          }, 'json');
        }
      });
    });
  </script>
</body>
</html>
