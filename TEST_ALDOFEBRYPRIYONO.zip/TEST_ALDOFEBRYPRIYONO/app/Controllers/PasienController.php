<?php

namespace App\Controllers;

use App\Models\PasienModel;
use CodeIgniter\Controller; 

class PasienController extends BaseController
{
    public function index()
    {
        return view('pasien/index');
    }

    public function list()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pasien');
        $builder->select('pasien.*, jenis_kelamin.nama AS nama_jenis_kelamin');
        $builder->join('jenis_kelamin', 'jenis_kelamin.id = pasien.jenis_kelamin_id', 'left');
        $data['pasien'] = $builder->get()->getResultArray();
        // Ambil diagnosis dari kunjungan terakhir untuk setiap pasien
        foreach ($data['pasien'] as &$row) {
            $builderKunjungan = $db->table('kunjungan');
            $builderKunjungan->select('diagnosis.nama_diagnosis');
            $builderKunjungan->join('diagnosis', 'diagnosis.id = kunjungan.diagnosis_id', 'left');
            $builderKunjungan->join('pendaftaran', 'pendaftaran.id = kunjungan.pendaftaranpasienid');
            $builderKunjungan->where('pendaftaran.pasienid', $row['id']);
            $builderKunjungan->orderBy('kunjungan.id', 'DESC');
            $diagnosis = $builderKunjungan->get()->getRowArray();
            $row['nama_diagnosis'] = $diagnosis['nama_diagnosis'] ?? '-';
        }
        unset($row);
        return view('pasien/_list', $data);
    }

    public function create()
    {
        $model = new PasienModel();
        $data = $this->request->getPost();
        // Validasi inputan
        if (empty($data['nama']) || empty($data['norm']) || empty($data['jenis_kelamin_id']) || empty($data['diagnosis'])) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Semua field harus diisi']);
        }
        $db = \Config\Database::connect();
        $db->transStart();
        $pasienId = $model->insert($data);
        // Simpan diagnosis
        $diagnosisData = [ 'nama_diagnosis' => $data['diagnosis'] ];
        $diagnosisId = $db->table('diagnosis')->insert($diagnosisData) ? $db->insertID() : null;
        // Simpan kunjungan dengan diagnosis
        if ($pasienId && $diagnosisId) {
            $db->table('pendaftaran')->insert([
                'pasienid' => $pasienId,
                'noregistrasi' => 'REG'.time(),
                'idregistrasi' => 'IDREG'.time()
            ]);
            $pendaftaranId = $db->insertID();
            $db->table('kunjungan')->insert([
                'pendaftaranpasienid' => $pendaftaranId,
                'jeniskunjungan' => 'Baru',
                'tglkunjungan' => date('Y-m-d'),
                'diagnosis_id' => $diagnosisId
            ]);
        }
        $db->transComplete();
        if ($db->transStatus() === false) {
            return $this->response->setJSON(['status' => 'error']);
        } else {
            return $this->response->setJSON(['status' => 'success']);
        }
    }

    public function get($id)
    {
        $model = new PasienModel();
        $data = $model->find($id);
        // Ambil diagnosis dari kunjungan terakhir
        $db = \Config\Database::connect();
        $builder = $db->table('kunjungan');
        $builder->select('diagnosis.nama_diagnosis');
        $builder->join('diagnosis', 'diagnosis.id = kunjungan.diagnosis_id', 'left');
        $builder->join('pendaftaran', 'pendaftaran.id = kunjungan.pendaftaranpasienid');
        $builder->where('pendaftaran.pasienid', $id);
        $builder->orderBy('kunjungan.id', 'DESC');
        $diagnosis = $builder->get()->getRowArray();
        $data['diagnosis'] = $diagnosis['nama_diagnosis'] ?? '';
        return $this->response->setJSON($data);
    }

    public function update($id)
    {
        $model = new PasienModel();
        $data = $this->request->getPost();
        // Validasi inputan
        if (empty($data['nama']) || empty($data['norm']) || empty($data['jenis_kelamin_id']) || empty($data['diagnosis'])) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Semua field harus diisi']);
        }
        $db = \Config\Database::connect();
        $db->transStart();
        $model->update($id, $data);
        // Update diagnosis di kunjungan terakhir pasien
        $builder = $db->table('kunjungan');
        $builder->select('kunjungan.id, kunjungan.diagnosis_id');
        $builder->join('pendaftaran', 'pendaftaran.id = kunjungan.pendaftaranpasienid');
        $builder->where('pendaftaran.pasienid', $id);
        $builder->orderBy('kunjungan.id', 'DESC');
        $kunjungan = $builder->get()->getRowArray();
        if ($kunjungan) {
            // Update diagnosis
            $db->table('diagnosis')->update(['nama_diagnosis' => $data['diagnosis']], ['id' => $kunjungan['diagnosis_id']]);
        }
        $db->transComplete();
        if ($db->transStatus() === false) {
            return $this->response->setJSON(['status' => 'error']);
        } else {
            return $this->response->setJSON(['status' => 'success']);
        }
    }
    // Hapus data pasien beserta relasi diagnosis, kunjungan, dan pendaftaran
    public function delete($id)
    {
        $db = \Config\Database::connect();
        $db->transStart();
        // Cari semua pendaftaran pasien
        $pendaftaran = $db->table('pendaftaran')->where('pasienid', $id)->get()->getResultArray();
        foreach ($pendaftaran as $row) {
            // Hapus kunjungan dan diagnosis terkait
            $kunjungan = $db->table('kunjungan')->where('pendaftaranpasienid', $row['id'])->get()->getResultArray();
            foreach ($kunjungan as $k) {
                $db->table('diagnosis')->where('id', $k['diagnosis_id'])->delete();
            }
            $db->table('kunjungan')->where('pendaftaranpasienid', $row['id'])->delete();
        }
        // Hapus pendaftaran pasien
        $db->table('pendaftaran')->where('pasienid', $id)->delete();
        // Hapus data pasien
        $db->table('pasien')->where('id', $id)->delete();
        $db->transComplete();
        if ($db->transStatus() === false) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Gagal menghapus data']);
        } else {
            return $this->response->setJSON(['status' => 'deleted']);
        }
    }
}