<?php

namespace App\Models;

use CodeIgniter\Model;

class PasienModel extends Model
{
    protected $table = 'pasien';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nama', 'norm', 'jenis_kelamin_id'];

    public function useTable($table)
    {
        $this->table = $table;

        switch ($table) {
            case 'pasien':
                $this->allowedFields = ['nama', 'norm', 'jenis_kelamin_id'];
                break;
            case 'pendaftaran':
                $this->allowedFields = ['pasienid', 'noregistrasi', 'idregistrasi'];
                break;
            case 'kunjungan':
                $this->allowedFields = ['pendaftaranpasienid', 'jeniskunjungan', 'tglkunjungan'];
                break;
            case 'asesmen':
                $this->allowedFields = ['kunjunganid', 'keluhan_utama', 'keluhan_tambahan'];
                break;
            case 'diagnosis':
                $this->allowedFields = ['nama_diagnosis', 'asesmenid'];
                break;
            case 'jenis_kelamin':
                $this->allowedFields = ['jenis'];
                break;
            default:
                throw new \Exception("Tabel tidak dikenal: " . $table);
        }

        return $this;
    }

    public function getDetailKunjunganLengkap($idKunjungan)
    {
        return $this->db->table('kunjungan')
            ->select('
                kunjungan.*, 
                pendaftaran.noregistrasi, 
                pasien.nama, 
                pasien.norm,
                jenis_kelamin.jenis AS jenis_kelamin,
                asesmen.keluhan_utama, 
                asesmen.keluhan_tambahan, 
                diagnosis.nama_diagnosis
            ')
            ->join('pendaftaran', 'pendaftaran.id = kunjungan.pendaftaranpasienid')
            ->join('pasien', 'pasien.id = pendaftaran.pasienid')
            ->join('jenis_kelamin', 'jenis_kelamin.id = pasien.jenis_kelamin_id', 'left')
            ->join('asesmen', 'asesmen.kunjunganid = kunjungan.id', 'left')
            ->join('diagnosis', 'diagnosis.asesmenid = asesmen.id', 'left') // pastikan struktur FK sesuai
            ->where('kunjungan.id', $idKunjungan)
            ->get()
            ->getRowArray();
    }
}
