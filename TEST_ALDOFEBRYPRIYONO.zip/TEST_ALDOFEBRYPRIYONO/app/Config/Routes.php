<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

// Routes untuk PasienController
$routes->get('pasien', 'PasienController::index');
$routes->get('pasien/list', 'PasienController::list');
$routes->post('pasien/create', 'PasienController::create');
$routes->get('pasien/get/(:num)', 'PasienController::get/$1');
$routes->post('pasien/update/(:num)', 'PasienController::update/$1');
$routes->get('pasien/delete/(:num)', 'PasienController::delete/$1');
